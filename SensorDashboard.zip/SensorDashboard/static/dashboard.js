let tempChart
let gasChart

async function fetchData(){

const res = await fetch('/api/data')
const data = await res.json()

if(data.length === 0) return

const latest = data[data.length-1]

// Update sensor values
document.getElementById("temp").innerText = latest.temp + " °C"
document.getElementById("hum").innerText = latest.hum + " %"
document.getElementById("mq2").innerText = latest.mq2
document.getElementById("mq135").innerText = latest.mq135

// Vibration display
if(latest.vib === 1){
document.getElementById("vib").innerText = "Detected"
document.getElementById("vib").className = "vibration-on"
}
else{
document.getElementById("vib").innerText = "None"
document.getElementById("vib").className = "vibration-off"
}

// AI Status display
const statusElement = document.getElementById("status")
statusElement.innerText = latest.status

statusElement.classList.remove("safe","warning","danger")

if(latest.status === "Safe"){
statusElement.classList.add("safe")
}
else if(latest.status === "Warning"){
statusElement.classList.add("warning")
}
else if(latest.status === "Danger"){
statusElement.classList.add("danger")
}

updateCharts(data)

}

function updateCharts(data){

const labels = data.map(d=>d.time)

const temps = data.map(d=>d.temp)
const mq2 = data.map(d=>d.mq2)
const mq135 = data.map(d=>d.mq135)


// Temperature Chart
if(!tempChart){

tempChart = new Chart(
document.getElementById("tempChart"),
{
type:'line',
data:{
labels:labels,
datasets:[
{
label:"Temperature",
data:temps,
borderColor:"red",
fill:false,
tension:0.3
}
]
},
options:{
responsive:true,
plugins:{
legend:{
display:true
}
}
}
})
}

else{

tempChart.data.labels = labels
tempChart.data.datasets[0].data = temps
tempChart.update()

}


// Gas Chart
if(!gasChart){

gasChart = new Chart(
document.getElementById("gasChart"),
{
type:'bar',
data:{
labels:labels,
datasets:[
{
label:"MQ2",
data:mq2,
backgroundColor:"orange"
},
{
label:"MQ135",
data:mq135,
backgroundColor:"blue"
}
]
},
options:{
responsive:true
}
})
}

else{

gasChart.data.labels = labels
gasChart.data.datasets[0].data = mq2
gasChart.data.datasets[1].data = mq135
gasChart.update()

}

}

// Refresh dashboard every 2 seconds
setInterval(fetchData,2000)

fetchData()
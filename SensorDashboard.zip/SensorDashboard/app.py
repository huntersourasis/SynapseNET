import pandas as pd
from sklearn.neighbors import KNeighborsClassifier

from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
from datetime import datetime

app = Flask(__name__)
CORS(app)

sensor_history = []

data = pd.read_csv("./dataset/coal_mine_sensor_dataset.csv")

X = data[['temp','hum','mq2','mq135','vib']]
y = data['status']

model = KNeighborsClassifier(n_neighbors=3)
model.fit(X, y)

print("KNN Model Loaded")


THRESHOLDS = {
    "mq2": 1000,
    "mq135": 1200,
    "temp": 40,
    "hum": 80,
    "vib": 1
}

@app.route("/")
def dashboard():
    return render_template("index.html")


@app.route("/api/data", methods=["POST"])
def receive_data():

    data = request.json

    temp = data.get("temp")
    hum = data.get("hum")
    mq2 = data.get("mq2")
    mq135 = data.get("mq135")
    vib = data.get("vib")

    sensor_df = pd.DataFrame([{
        "temp": temp,
        "hum": hum,
        "mq2": mq2,
        "mq135": mq135,
        "vib": vib
    }])

    prediction = model.predict(sensor_df)[0]

    entry = {
        "time": datetime.now().strftime("%H:%M:%S"),
        "node": data.get("node"),
        "mq2": mq2,
        "mq135": mq135,
        "vib": vib,
        "temp": temp,
        "hum": hum,
        "status": prediction
    }

    sensor_history.append(entry)

    if len(sensor_history) > 50:
        sensor_history.pop(0)

    return jsonify(entry)


@app.route("/api/data", methods=["GET"])
def get_data():
    return jsonify(sensor_history)



@app.route("/api/thresholds")
def thresholds():
    return jsonify(THRESHOLDS)



if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)